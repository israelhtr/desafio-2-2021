import sys
import json

"""dict = {
	"room": "bathroom-main",
	"values": {
		"co2": 4800,
		"temperature": 22,
		"humidity": 70,
		"sound": 350,
		"illumination": 150
	}
}"""


def bathroom(values):

    for x, y in values.items():
        if x == "co2" and y > 500:
            alerts_list.append(x)

        elif x == "temperature" and (y < 22 or y > 25):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "humidity" and (y < 60 or y > 75):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "sound" and (y < 20 or y > 35):
            alerts_list.append(x)
            #print(alerts_list)

        elif x == "illumination" and (y < 100 or y > 200):
            alerts_list.append(x)
            #print(alerts_list)

    return alerts_list


def activity(values):

    for x, y in values.items():
        if x == "co2" and y > 500:
            alerts_list.append(x)

        elif x == "temperature" and (y < 19 or y > 22):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "humidity" and  (y < 50 or y > 60):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "sound" and (y < 0 or y > 40):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "illumination" and (y < 300 or y > 750):
            alerts_list.append(x)
            # print(alerts_list)

    return alerts_list

def garden(values):

    for x, y in values.items():
        if x == "co2" and y > 500:
            alerts_list.append(x)

        elif x == "temperature" and (y < 15 or y > 22):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "humidity" and  (y < 50 or y > 80):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "sound" and (y < 10 or y > 35):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "illumination":
	    # alerts_list.append(x)
	    # print(alerts_list)
            pass

    return alerts_list

def refectory(values):

    for x, y in values.items():
        if x == "co2" and y > 400:
            alerts_list.append(x)

        elif x == "temperature" and (y < 20 or y > 23):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "humidity" and  (y < 50 or y > 70):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "sound" and (y < 20 or y > 35):
            alerts_list.append(x)
            # print(alerts_list)

        elif x == "illumination" and (y < 200 or y > 500):
            alerts_list.append(x)
            # print(alerts_list)

    return alerts_list

def room_1(values):

    for x, y in values.items():
        if x == "co2" and y > 300:
            alerts_list.append(x)

        elif x == "temperature" and (y < 21 or y > 23):
            alerts_list.append(x)
	    # print(alerts_list)

        elif x == "humidity" and  (y < 50 or y > 60):
            alerts_list.append(x)
	    # print(alerts_list)

        elif x == "sound" and (y < 10 or y > 30):
            alerts_list.append(x)
	    # print(alerts_list)

        elif x == "illumination" and (y < 100 or y > 200):
            alerts_list.append(x)
	    # print(alerts_list)

    return alerts_list

def main(dict):
	global alerts_list
	alerts_list = []
	results = {"alerts": alerts_list}
	#dict = json.load(dict)

	if dict["room"] == "bathroom-main":
	    alerts_list = bathroom(dict["values"])

	elif dict["room"] == "activity-room":
	    alerts_list = activity(dict["values"])

	elif dict["room"] == "garden":
	    alerts_list = garden(dict["values"])

	elif dict["room"] == "refectory":
	    alerts_list = refectory(dict["values"])

	elif dict["room"] == "room-1":
	    alerts_list = room_1(dict["values"])

	#print(dict["room"])

	return {'alerts' : alerts_list}
